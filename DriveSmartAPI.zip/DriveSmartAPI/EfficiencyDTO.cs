﻿namespace DriveSmartAPI.DTOs
{
    public class EfficiencyDTO
    {
        public double Efficiency { get; set; }
        public string VehicleId { get; set; }
        public DateTime DateTime { get; set; }
    }
}
